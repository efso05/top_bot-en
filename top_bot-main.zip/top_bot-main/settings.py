settings = {
    "prefix": ">",
    "TOKEN": "ТУТ ТОКЕН"
}